package net.bigpoint.assessment.gasstation;

import java.util.ArrayList;
import java.util.Collection;

import net.bigpoint.assessment.gasstation.exceptions.GasTooExpensiveException;
import net.bigpoint.assessment.gasstation.exceptions.NotEnoughGasException;

public class GasStationImpl implements GasStation{

	ArrayList<GasPump> gasPumps = new ArrayList<GasPump>();
	private  double revenue;
	private int cancellationsNoGas;
	private int cancellationsTooExpensive;
	private int numberOfSales;
	public void addGasPump(GasPump pump) {
		// TODO Auto-generated method stub
		gasPumps.add(pump);
		
	}

	public Collection<GasPump> getGasPumps() {
		// TODO Auto-generated method stub
		return gasPumps;
	}

	public double buyGas(GasType type, double amountInLiters,
			double maxPricePerLiter) throws NotEnoughGasException,
			GasTooExpensiveException {
		// TODO Auto-generated method stub
		double available_ltrs=0;
		double expectedRevenue=maxPricePerLiter * amountInLiters;
		if(maxPricePerLiter < getPrice(type))
		{
			cancellationsTooExpensive++;
			throw new GasTooExpensiveException();
		}
		synchronized (this) {
			for (GasPump pump : gasPumps)
			{
				if(pump.getGasType() == type)
				{
					available_ltrs= available_ltrs + pump.getRemainingAmount();
					
				}
				
			}
			if(amountInLiters > available_ltrs)
			{
				cancellationsNoGas++;
				throw new NotEnoughGasException();
			}
			else
			{
				double remaininglitres = amountInLiters;
				for (GasPump pump : gasPumps)
				{
					
					if(amountInLiters > 0) // still we need to pump
					{
						if(pump.getGasType()== type)
						{
							
							if(pump.getRemainingAmount() < amountInLiters)
							{
								remaininglitres = amountInLiters - pump.getRemainingAmount();
								pump.pumpGas(pump.getRemainingAmount());
								
							}
							else
							{
								pump.pumpGas(amountInLiters);
								remaininglitres = 0;
							}
							amountInLiters=remaininglitres;
						}
					}
					
				}
				numberOfSales++;
				revenue = revenue + expectedRevenue;
				return expectedRevenue;
			}
			
		}
		
		
	}

	public double getRevenue() {
		// TODO Auto-generated method stub
		return revenue;
	}

	public int getNumberOfSales() {
		// TODO Auto-generated method stub
		return numberOfSales;
	}

	public int getNumberOfCancellationsNoGas() {
		// TODO Auto-generated method stub
		return cancellationsNoGas;
	}

	public int getNumberOfCancellationsTooExpensive() {
		// TODO Auto-generated method stub
		return cancellationsTooExpensive;
	}

	public double getPrice(GasType type) {
		// TODO Auto-generated method stub
		
		return type.getValue();
	}

	public void setPrice(GasType type, double price) {
		// TODO Auto-generated method stub
		type.setValue(price);
	}

}
