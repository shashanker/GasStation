package net.bigpoint.assessment.gasstation;

public enum GasType {
	REGULAR,
	SUPER,
	DIESEL;
	
//	REGULAR(100),
//	SUPER(200),
//	DIESEL(50);
	private  double value;
	public void setValue(double value)
	{
		this.value=value;
	}
    public double getValue() { return value; }

}






