package net.bigpoint.assessment.gasstation.exceptions;

/**
 * This exception is thrown whenever gas could not be bought because the price was too high
 * 
 */
public class GasTooExpensiveException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2581151114207596829L;
	
	public GasTooExpensiveException() {
		// TODO Auto-generated constructor stub
		System.out.println("Gas request cannot be solded at that price");
	}
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Gas request cannot be solded at that price";
	}
	

}
