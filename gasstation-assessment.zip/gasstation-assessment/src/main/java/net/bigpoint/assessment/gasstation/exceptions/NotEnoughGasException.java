package net.bigpoint.assessment.gasstation.exceptions;

/**
 * This exception is thrown whenever gas could not be bought because not enough was available
 * 
 */
public class NotEnoughGasException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4577139900795204370L;
	
	public NotEnoughGasException() {
		// TODO Auto-generated constructor stub
		
		System.out.println("Sorry .. Request amount of Gas is not available");
	}
	
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Sorry .. Request amount of Gas is not available";
	}

}
